/*
 * Header.h
 *
 *  Created on: Feb 23, 2017
 *      Author: pamela
 */

#ifndef HEADER_H_
#define HEADER_H_

#include <iostream>
#include <cstdlib>
#include <cmath>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <sstream>
#include <fstream>

#endif /* HEADER_H_ */
